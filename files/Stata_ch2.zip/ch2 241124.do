// ================================
//
// Copyright by George Chou
// All rights reserved
// 
// filename: ch2_data_visualization
// description: for the stata training course chapter 2.
//
// created by George Chou at 14/11/2024 14:29:44
// notes: 本代码仅供中南财经政法大学财政税务学院2024年Stata基础训练营教学使用，请勿传播。
//
// ================================



* Stata基础训练营第一期 课程讲义

* 第二讲 数据可视化 Data Visualization

* 主讲人：周智霖	2024年11月24日



* ---------------------------------

* 本讲我们将提供三个数据集作为实例。



* 第一个为Boston房价数据（boston_housing_data.dta）
* 该数据为1970年Boston市的截面数据，包含美国人口普查局收集的Boston住房价格有关数据。
* 其中核心变量为空气质量即nox以及价格即medv，我们将逐一介绍各变量的含义。
	* crime 城镇人均犯罪率
	* zone 占地面积超过25000平方英尺的住宅用地占地比例
	* industry 每个城镇中非商业用地占地比例
	* charles Charles River虚拟变量（如果区域边界为河道则为1，否则为0）
	* nox 一氧化氮浓度（每千万份）
	* room 每间住宅的平均房间数
	* age 1940年以前建造的自住房的比例
	* distance 到Boston五个就业中心的加权距离
	* rad 放射状高速公路的可达性指数
	* tax 每10000美元的房产税税额
	* piratio 城镇中的学生与教师比例
	* bk 城镇中黑人比例（经换算过）
	* lstat 房东属于低收入阶层的比例
	* medv 自住房的价格中位数（每千美元）



* 第二个为CFPS中国家庭追踪调查数据（cfps_combined_data.dta）
* 该数据切取的为2016~2022共四期的面板数据，包含基本人口学信息、婚姻与生育、工资与就业等部分信息。
* 我们将逐一介绍各变量的含义。
	* pid 个人编号（individual）
	* year 调查年份（time）（CFPS为两年度调查，故八年时间仅有四期数据）
	* gender 性别
	* ibirthy 出生年份
	* age 年龄
	* edu 受教育程度
	* marriage 婚姻状态
	* qka202 期望拥有的孩子数量
	* qka203 期望拥有的男孩数量
	* qg401 工作收入满意度（5分制，分数越高代表对工作收入越满意）
	* qg11 每月税后工资
	* qn6014 对我国就业问题严重程度的评估（10分制，分数越高代表受访者认为问题越严重）



* 第三个为Stata基础训练营的课前调查问卷数据（survey_data.dta）
* 该数据为截面数据，下面将逐一介绍各变量的含义。
	* grade 年级（为平衡比例，研究生和本科四年级统一赋值为4）
	* gender 性别（男=1 女=2）
	* employ 就业难度（10分制，分数越高代表越困难）
	* employ_opt 找到理想工作的难度（10分制，分数越高代表越困难）
	* res_wage 保留工资（能接受的最低工资）
	* first_wage 认为第一份工作的工资

	
	
* ---------------------------------



* 复习一下上节课数据处理的操作：现在我们有四期的截面数据，我们需要合成为一个面板。

* 首先要做的是完整仔细地浏览每个数据集，统一变量名。
cd ""
use cfps_2016_raw_data.dta, clear
rename (cfps_age cfps_gender cfps_latest_edu cfps2014_marriage_update) (age gender edu marriage) // 2016年数据中，部分变量名和其他数据集中的变量名不一致。

use cfps_2022_raw_data.dta, clear
gen age  = 2024 - ibirthy // 2022年数据中，未显示年龄而是出生年份，故需要做一定调整。
drop ibirthy

* 其次是要统一个体变量和时间变量，此处个体变量均为pid，时间变量通常截面数据中未设定，需自己设定。
use cfps_2020_raw_data.dta, clear
gen year = 2020 // 节省时间，其他三期均为大家设定好时间变量。

* 现在我们使用append命令进行纵向的多数据集合并：
* 方法一：常规做法
use cfps_2016_raw_data.dta, clear
append using cfps_2018_raw_data.dta
append using cfps_2020_raw_data.dta
append using cfps_2022_raw_data.dta

* 方法二：采用循环语句
local files "cfps_2016_raw_data cfps_2018_raw_data cfps_2020_raw_data cfps_2022_raw_data"
foreach file of local files {
    if "`file'" == "cfps_2016_raw_data" {
        use `file'.dta, clear
    }
    else {
        append using `file'.dta
    }
}

* 得到的合并数据集建议另存为另一个.dta文件。

* 使用order命令对变量排序，使用xtset命令查看面板数据的格式。
order pid year
xtset pid year
* 可以发现该数据为非平衡面板，时间跨度为2016-2022年。

* 仅保留平衡面板的做法：引入count函数。
bys pid: egen num = count(pid)
keep if num == 4 // 因为一共有四期数据。
drop num
xtset pid year

label list // 其中部分数据是以标签形式展示，此命令可以显示数值与标签的对应关系。



* ---------------------------------



* Episode I. Introduction

* 在进入具体的图形绘制前，我们先介绍绘图中的通用元素。

* 对于存在高级图形选项或一些自定义的绘图来说，命令大多以graph或twoway开头。
* 但对于最基本的绘图命令（比如随手看看数据构成？），则可以省略，如下述的一个命令：
use boston_housing_data.dta, clear
scatter medv nox
* 它绘制了以medv为纵轴、nox为横轴的散点图（下面会详细介绍），我们本小节以这个命令为例。

* 通用的绘图命令格式：graph graph_choice (plot_choice, plot_options) (the same...), graph_options
* graph_choice / plot_choice 即选择要绘制哪种图形，我们会在第二节介绍。
* graph_options / plot_options 即自定义图形的各种元素选项，我们会在第三节介绍。
* 常见图形选项：title / subtitle / ytitle / xtitle / legend / caption / note
* 对应的中文：主标题、副标题、y轴标题、x轴标题、图例、题注（即“图N: XXX”）、注释。
* 如下述命令：
graph twoway (scatter medv nox, ytitle(price) xtitle(pollution)), ///
title(A funny figure) subtitle(Which is absolutely meaningless) ///
caption(Figure 1: Economic Science) note(Notes: Don't be cheated by those people.)

* 另外我们讲一个调整图形风格的一系列代码。
graph query, scheme // 查看所有可用图形风格

* 我们默认的图形风格是s2color，我们需要通过手动设置的方法改变风格。
set scheme sj // 设定风格为Stata Journal
scatter medv nox

* 大家可以再试试其他常用风格。如果说想更改默认风格，则需要用到下述代码：
set scheme sj, perma // 注意要改回s2color的话需要重新运行相应代码



* ---------------------------------



* Episode II. Basic Graphs

* 在学习基本图形的绘制中，我们通常按两个维度来区分图的类型：单变量与双变量（多变量）、连续型与离散型。

* 我们所提供的三个数据集中，课前调查数据则混合了多种数据形式，Boston房价数据以连续型数值数据居多，而CFPS数据则主要用于面板数据作图。



* Section I. Discrete Variable

* 首先要学习的是离散型变量的作图。

* 第一种图形我们用课前调查数据展示，我们先给年级和性别两个变量中的数值贴标签：
use survey_data, clear
label define grade_label 1 "本科一年级" 2 "本科二年级" 3 "本科三年级" 4 "本科四年级"
label values grade grade_label
label define gender_label 1 "男" 2 "女"
label values gender gender_label

* 首先是饼图，其能够很好的显示分类数据不同变量之间的占比大小。我们展示一个基本的饼图命令：
graph pie, over(grade)

* 加入一些选项，比较添加与否的不同点：
graph pie, over(grade) missing // 加入缺失值（默认绘图是省略缺失值的）
graph pie, over(grade) noclockwise // 逆时针排序
graph pie, over(grade) angle0(0) // 调整首个扇区的起始角度（此处设为0度即水平）
graph pie, over(grade) sort // 按百分比大小升序排序
graph pie, over(grade) sort descending // 按百分比大小降序排序
graph pie, over(grade) sort pie(3, explode) // 突出显示第3块扇区
graph pie, over(grade) plabel(_all percent) // 显示百分比
graph pie, over(grade) plabel(_all sum) // 显示总数量
graph pie, over(grade) plabel(_all name) // 显示标签名

* 利用另一变量作为分类，同时画多个饼图：
graph pie, over(grade) by(gender) // 分别展示男性和女性的年级占比

* 尝试使用CFPS中的marriage变量再完成一遍以上操作（注意使用截面，加入 if year==2022 条件）

* 在这里我们以饼图为例讲解一下图形合并。
* 先作出来两个饼图，然后暂时保存。（注意保存出来的必定为.gph格式）
graph pie, over(grade) title(grade_pie) saving(grade_pie) 
graph pie, over(gender) title(gender_pie) saving(gender_pie)
* 利用combine命令进行合并
graph combine grade_pie.gph gender_pie.gph, row(1) // 合并在一行
graph combine grade_pie.gph gender_pie.gph, col(1) // 合并在一列



* 接下来是柱状图。我们依然以grade变量为例，展示一个基本的柱状图命令（实际上也与饼图类似）：
graph bar, over(grade) // 这里依然是计算比例

* 下面我们用CFPS数据展现时间序列的柱状图绘制。
use cfps_combined_data.dta, clear
graph bar (mean) qg11, over(year) // 以年份为横轴，每年的人均月工资为纵轴画图。

* 上面是按年份的单分类柱状图，下面我们展示一个双分类柱状图。
graph bar (mean) qg11, over(year) over(gender), if gender!=-8 // 以年份为横轴，再按性别分类（if条件是避免出现性别不适用的样本）

* 尝试更换上一行代码中两个over条件的顺序，发现有什么不同。
graph bar (mean) qg11, over(year) by(gender), if gender!=-8 // 双分类的另外一种形式

* 我们更换到Boston房价数据集，展示另外两种多变量的柱状图。（此处仅为代码演示，无任何实际意义）
use boston_housing_data.dta, clear
graph bar medv lstat, over(rad), if rad!=24 // 并排柱状图，同时展现medv和lstat两个数据。
graph bar medv lstat, stack over(rad), if rad!=24 // 堆叠柱状图，将两个柱形堆叠在一起。

* 以上所有命令中将bar改为hbar即为水平柱状图，大家可以自行尝试。

* 将bar改为dot，再看看又什么不同。（实际上这就得到了点图）



* Section II. Continuous Variable 1

* 下面我们来学习单连续变量的作图。

* 先展示直方图的绘制，下面是一个使用Boston房价数据的例子。
use boston_housing_data.dta, clear
histogram tax // 注意直方图前面不能加graph了，这里默认纵轴是density即频率还要除以组距。
histogram tax, freq // 这里纵轴即出现频数
histogram tax, frac // 这里纵轴变为频率
histogram tax, percent // 这里即变为百分比，也就是100*fraction

* 刚才我们调整了纵轴的展示方式，下面我们尝试调整横轴。
histogram tax, bin(10) // 更改分组数为10组
histogram tax, width(50) // 更改组距为50
histogram tax, start(50) // 从50开始计数（这个开始计数值不得高于数据的最小值）

* 添加一些其他元素：
histogram tax, normal // 添加一条正态曲线
histogram tax, kdensity // 添加对应的核密度曲线

* 我们还可以加入数值标签
histogram tax, percent addlabels

* 展示一个稍微高级的分组直方图：
twoway (histogram tax if charles==1, percent fcolor(gs12) lcolor(gs12) width(25) start(187)) ///
(histogram tax if charles==0, percent fcolor(none) lcolor(black) width(25) start(187)), ///
legend(label(1 "charles") label(2 "non-charles")) ///
graphregion(color(white)) title("This is a advanced histogram example") // fcolor和lcolor是为了区分颜色
* 想想为什么要同时控制start和width，后面在高级技巧中会给大家解析其他因素。



* 下面是核密度图，实际上已经在直方图中讲解过。
twoway (kdensity tax), xtitle("tax") // 选项和其他图基本一致

* 一个高级操作：核密度中加入面积，原理是画一个和核密度图重合的线图，然后在下方绘制面积图。
kdensity price, gen(x h)
local threshold=400 // 此处以400为阈值
twoway (line h x) (area h x if x<`threshold'), legend(off)

sum tax, mean
local mean=r(mean) // 此处以数据的均值为阈值
kdensity price, gen(x h)
twoway (line h x) (area h x if x<`threshold'), legend(off)



* Section III. Continuous Variable 2

* 下面我们来学习多连续变量的作图。

* 首先是折线图，通常用于时间序列的绘制。我们用CFPS数据演示。
use cfps_combined_data.dta, clear
twoway line qg11 year if pid==230375101 // 单折线图

* 为了演示方便，我们定义一个新变量来画双折线图。
gen qg12 = qg11 + 200
twoway (line qg11 year) (line qg12 year) if pid==230375101  // 双折线图
twoway line qg11 qg12 year if pid==230375101 // 另一种语法
twoway line qg11 qg12 year if pid==230375101, lpattern(solid dash) // 还可以调整线的类型
twoway line qg11 qg12 year if pid==230375101, lwidth(1.2 1.3) // 调整线的宽度
twoway line qg11 qg12 year if pid==230375101, lcolor(red blue) // 调整线的颜色
twoway (line qg11 year, yaxis(1)) (line qg401 year, yaxis(2)) if pid==230375101 // 使用两个坐标轴

* 尝试将line替换成connected，就会得到连线图。观察有什么不同。



* 最后我们来到散点图以及拟合线图，我们回到最初的那个例子：
use boston_housing_data.dta, clear
twoway scatter medv nox // 绘制散点图

* 接着我们开始绘制拟合线图：
twoway lfit medv nox // 线性拟合
twoway qfit medv nox // 二次拟合

* 在拟合线图中加入95%置信区间：
twoway lfitci medv nox // 线性拟合+置信区间
twoway qfitci medv nox // 二次拟合+置信区间

* 合并两个图形（以scatter和lfitci为例）
twoway (lfitci medv nox) (scatter medv nox), xtitle(nox) ytitle(medv)

* 尝试交换lfitci和scatter的位置，想想twoway合并图形中是否存在顺序。

* 我们演示一个散点图的变种：气泡图
gen medvrate = medv / room // 定义平均每个房间的价格
label var medvrate "price per room"
scatter medvrate nox [w=room], msymbol(circle_hollow) // 气泡大小即房间数（虽然本图有点不明显）



* ---------------------------------



* Episode III. General Options

* 继续回到最开始的例子，加入一条线性拟合线（带置信区间）和一条二次拟合线。
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) ///
title(A funny figure) subtitle(Which is absolutely meaningless) ///
caption(Figure 1: Economic Science) note(Notes: Don't be cheated by those people.)

* 这里我们已经展示了如何更改标题、副标题、坐标轴标题、题注和注释。
* 下面为了图形比例，我们删去标题、副标题、题注和注释的选项。
* 现在我们演示如何改变图例。
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(ring(0) pos(5)) // 放置图例在图中，大概5点钟方向。
* ring和position的具体选项请使用help title_options命令查看。

* 我们想只用一排图例时：
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(row(1))

* 同样地，只想用一列图例时：
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(col(1))

* 如果我们想取消图例的展示，则可以使用：
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(off)

* 对坐标轴也可以如此使用。

* 如果我只想保留特定图例，则可以使用：
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(order(2 "linear fit" 3 "quad fit")) // 仅保留原图例中的第二个lfit和第三个qfit



* 让我们先关闭图例，定制一下坐标轴。（坐标轴的名字已经展示过）
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(off) ///
xlabel(, tposition(inside)) ylabel(, tposition(inside)) // 调整坐标刻度线的位置为向内

* 尝试更换inside为crossing或outside，观察有什么不同。

* 思考一下这里xlabel(, tposition(inside))中，为什么逗号前面没有命令也要打逗号。（这个问题很重要）

* 更改一下坐标轴起始值：
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(off) ///
plotregion(margin(0)) // 设置为0

* 尝试更换margin()中的参数为-5 -10 -20，观察有什么不同。

* 延伸坐标轴：
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(off) ///
xscale(extend) yscale(extend)

* 尝试更改为fextend，观察有什么不同。

* 更改坐标轴标度（我们这里只更改纵轴）
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(off) ///
yscale(log) // 更改为对数标度

* 尝试更改为reverse，观察有什么不同。



* 最后我们展示一下添加文字。
graph twoway (lfitci medv nox) (qfit medv nox) (scatter medv nox), ///
ytitle(price) xtitle(pollution) legend(off) ///
text(30 0.8 "Class is over.", place(3)) // 先写纵坐标再写横坐标，place参数用于固定大概位置。



* ---------------------------------

* 本讲只用到了三个数据集中的部分变量，大家可以利用其他变量进行有关图形的绘制。

* 注意区分不同图形的用法，如柱状图or直方图，散点图or拟合线等。

* 另外像箱线图box，小提琴图vioplot等不太常用的图形我们未涉及到，大家有兴趣可以自行探索。

* 没有讲到的函数图function是一个非常有用的画函数的工具，大家可以进行一些学习。



* ---------------------------------

* 省级地图绘制

use china_map_value, clear
grmap, activate
grmap Value using chinaprov40_coord, /// 绘制各省轮廓
	id(ID) osize(vvthin ...) ocolor(white ...) ///
	clmethod(custom) clbreaks(-1 0 40 80 120 160 200) /// 取值范围
	fcolor(gray "254 237 222" "253 190 133" "253 141 60" "230 85 13" "166 54 3") /// 更改颜色
	legend(order(2 "No Data" 3 "< 40" 4 "40~80" 5 "80~120" 6 "120~160" 7 "> 160")) /// 加入标签
	graphr(margin(medium)) ///
	line(data(chinaprov40_line_coord.dta) /// 调整轮廓线样式
		select(keep if inlist(group, 1, 2, 3, 5, 6)) ///
		by(group) size(vvthin *1 *0.5 *0.5 *0.5) ///
		pattern(solid ...) ///
		color(white black "0 85 170" black black)) /// 
	polygon(data(china_map_compass) fcolor(black) osize(vvthin)) /// 
	label(data(china_map_label) x(X) y(Y) label(ename) length(20) size(*0.6)) ///
	title("This_is_our_homeland")
graph export province_map.png, replace width(1200)

* 市级地图绘制

use "data_fig3.dta", clear 
grmap, activate
grmap mono using chinacity2020_coord.dta, ///
	id(ID) osize(vvthin ...) ocolor(white ...) ///
	clmethod(custom) clbreaks(-1  0 25 50 75 100 ) ///
	fcolor("gs10" "224 242 241" "178 223 219" "128 203 196" "77 182 172" "38 166 154") ///
	legend(order(2 "No data" 3 "<25%" 4 "25%~50%" 5 "50%~75%" 6  ">75%" )) ///
	graphr(margin(medium)) ///
	line(data(chinacity2020_line_coord3.dta) by(group) ///
		size(vvthin *1 *0.5 *0.5 *0.5) pattern(solid ...) ///
		select(drop if inlist(group, 4, 7)) ///
		color(white black "0 85 170" black black)) ///
	polygon(data(china_map_compass) fcolor(black) osize(vvthin)) /// 
	label(data(china_map_label) x(X) y(Y) label(ename) length(20) size(*0.6)) ///
	title("This_is_our_homeland")
graph export figure3.png, replace width(1200)