
                         *========================================
                         *           Stata基础训练营讲义
                         *========================================
	                     *       =========================
                         *         Ch3  回归分析与结果输出
                         *       =========================
		 
          		  
		                 *           主讲人：江俊澄
                         *     中南财经政法大学财政税务学院
		                 *          学生学术科研中心
		                 *            2024年12月1日
		  
		  
		  
	 
*---------------------------------
*->  1 安装外部命令
*---------------------------------

      sysdir   //查看安装路径
	  ssc install xxx
	  
	  help ssc
	   
	  
	  

*---------------------
*-> 2.   相关分析
*---------------------
		  
		  
    * 一般来说，变量之间的关系分为两种，一种确定的函数关系，一种不确定的关系，即相关关系；
		  
    * 相关分析，是研究变量之间相关关系的一种重要方法；
		   
    * 相关分析方法，不仅可以对变量之间的相关性进行研究，正相关负相关进行说明，还可以对变量之间的相关程度进行说明；
		  
    * 相关分析能够说明变量之间相互依存关系，若是变量之间相关系数值很大，那就说明变量之间存在很强的相关性。
		  
    * 相关分析目的在于研究和讨论各个变量之间的密切程度或者关联程度。
		  
    * 对于变量之间的相关方向以及相关程度都可以通过相关分析进行统计分析，对于变量之间密切程度可以通过相关系数作为统计指标?
		  
    * 本文将采用相关系数法来研究和讨论各个变量间的相关关系。
		  
		  
*-------------------
*-> 2.1   correlate
*-------------------		 		  
		  	  
    sysuse auto, clear  //调用美国1978年汽车行业截面数据	
		  
    help  correlate       //查看相关分析命令的帮助文件
		  
    correlate price weight mpg turn foreign
    

    菜单操作步骤

    correlate

    Statistics > Summaries, tables, and tests > Summary and descriptive
    statistics > Correlations and covariances
	
		
**************2.2 获得相关变量的显著性检验*********************

    correlate price weight mpg turn foreign
	
**************获得相关变量的显著性检验,并且标注*********************

	pwcorr price weight mpg turn foreign, sig star(.05) print(.05)	
	pwcorr price weight mpg turn foreign, sidak sig  star(.05)
	pwcorr price weight mpg turn foreign, sidak sig  star(.05) print(.05)
	   
	   
**************三种显著性水标注*********************

	
	pwcorr_a price weight mpg displ, star1(0.01) star5(0.05) star10(0.1)
	
	
	
	
*---------------------
*-> 3.   回归分析
*---------------------
	
		  
    * 计量经济学家的根本任务就是从现实中挖掘变量之间的关系。 
	
    * 各种变量用X、Y等字母表示，而这些变量的关系往往体现为他们之间的函数关系Y=f(X)。
	
    * 函数关系刻画了某个变量如何伴随着另一个（些）变量的变化而变化。
	
********3.1 含义与定义*****	  
  
    * 回归分析主要是根据回归模型，确定被解释变量与解释变量之间的定量关系，
	 	 
    * 回归分析是计量经济学分析中最基础和最核心的分析方法之一，为研究变量之间的
    * 因果关系和相关关系提供了一种重要的手段  
    
    /* 回归分析的主题思想是将被解释变量与解释变量，即因变量和自变量，y和x，其
    基本思想是将被解释变量作为因变量，将其他影响因素作为解释变量
	然后研究因变量和自变量之间的关系
	 */
  
 
 
*---------------------
*-> 3.2   reg回归
*---------------------
 
********普通最小二乘法  reg**********	

	 
      help  reg
	 
	* 菜单操作	Menu
	
	* Statistics > Linear models and related > Linear regression

	* 命令格式为
	 
	 regress depvar [indepvars] [if] [in] [weight] [, options]  //因变量，自变量
	 
	
	 
////////////普通最小二乘法分析流程////////////

	 
//普通最小二乘法
	 	 
    sysuse auto, clear
    regress weight length, noconstant

    edit //对数据进行编辑查看
    summ  price mpg //对数据进行描述性分析
    corr  price mpg //对数据进行相关性分析

    reg price weight mpg turn foreign //对数据进行回归分析

    predict yhat,xb        //xb表示对因变量进行线性预测   //对因变量的拟合值进行预测
	

    predict e,residual   //residual表示对进行进行时间序列预测  //回归分析得到残差	
	
	
********************************************************************************
cd "C:\Users\czxia\Desktop\stata ch3 "


use "Dec 1.dta",clear
*进行回归前，对书籍进行描述分析和查看数据特征	 
    *edit          /编辑/	 
    *browse     / 浏览/	 
    *describe
	 *最小二乘法进行回归

reg y x	 
regress y x, noconstant 
		 

*Now we can move to regressions


reg patent books  gdp_per

reg patent books gdp_per population 

gen population2=population^2
gen book2=books^2

reg patent books gdp_per gdp_per2 population population2

reg patent books book2 gdp_per gdp_per2 population population2

reg patent books gdp_per population i.year i.city

reg patent books gdp_per population i.year i.city,nocons

reg patent books gdp_per population i.year i.city


*ways to add FE: dummies

*way 1
reg patent books gdp_per population i.year i.pr

*way 2
tab 所属省份,gen(p)

reg patent books gdp_per population i.year p2-p27


*with if conditions
reg patent books gdp_per population i.year i.city if km_sq<5000






sum km_sq
gen km_sqmean=r(mean)

reg patent books gdp_per population i.year i.city if km_sq<=km_sqmean

reg patent books gdp_per population i.year i.city if km_sq>km_sqmean


*regression results
reg patent books gdp_per population i.year i.city 

display _b[_cons]
display _b[gdp_per]

display _b[_cons] + _b[gdp_per]



*---------------------
*-> 3.2   ivreg回归
*---------------------


ssc install ivreg2

  
ssc install ranktest //安装外部命令ivreg2

/*
回顾IV、2SLS的含义
首先回顾一下工具变量的含义，
工具变量是指与模型中内生变量强相关，但是与误差项不相关的变量。

工具变量法就是使用工具变量，替代模型中与误差项相关的内生解释变量进行估计的方法。

其中，最常用的工具变量估计方法是两阶段最小二乘法（2SLS）。

那么两阶段最小二乘回归法包含哪两个阶段呢？

第一阶段：将内生变量作为被解释变量，将工具变量和模型中的外生变量作为解释变量，
进行OLS估计。通过外生变量的预测回归，得到内生变量的拟合值，
从而消除内生解释变量的内生性； 


第二阶段：用第一阶段得到的内生变量的拟合值替换内生变量真实值，
再进行OLS估计，从而消除偏误。


一个合格的工具变量需要满足"与内生解释变量强相关"、"与误差项完全不相关"两个条件，

因此，一个工具变量需要经过一系列的检验才能被认为是好的工具变量。
*/
	
	
/*
内生性检验：检验核心变量是否是内生变量。如果一个变量不是内生变量，那么不需要使用IV估计。
相关性检验：检验工具变量是否与内生变量强相关。如果工具变量与内生变量相关性很弱，说明工具变量的选择是有问题的。
外生性检验：检验工具变量是否具有外生性。如果工具变量不具有外生性，那么2SLS估计结果也可能比OLS估计结果偏差更大。	
*/

sysuse auto,clear
ivreg2 mpg weight (length=displacement),first savefp(first)
eststo second
outreg2 [firstlength second] using iv_ivreg2.xlsx, tstat bdec(4) tdec(4) replace


/*
sysuse auto.dta, clear
eststo clear
eststo m1: ivreg2 price mpg foreign (weight = trunk), first savefirst savefprefix(first_)


estadd scalar cdf1 =  `e(cdf)': first_wegiht
estadd scalar sstat1 = `e(sstat)': first_weight

esttab  first_weight m1 using "${OUTPATH}第一阶段结果.rtf", ///
coeflabels(_cons "常数项") replace ///
b(3) se(3) compress scalar(F) ///
order(trunk weight price mpg length) ///
stats(N r2 cdf1 sstat1, fmt(0 3 3 3) labels("观测值" "拟合优度" "CD Wald F" "SW S stat.")) ///
nobaselevels star(* 0.10 ** 0.05 *** 0.01)
eststo clear


eststo clear：清除之前存储的估计结果。

eststo m1: ivreg2 price mpg foreign (weight = trunk), first savefirst savefprefix(first_)：

eststo m1:：存储接下来的估计结果，并将其命名为m1。
ivreg2：执行工具变量回归的命令。
price mpg foreign (weight = trunk)：price是因变量，mpg和foreign是自变量，而weight是使用工具变量trunk估计的内生变量。

, first：首先执行第一阶段的回归，并输出结果。

savefirst：保存第一阶段的回归结果。
savefprefix(first_)：指定保存第一阶段结果时文件名的前缀为first_。
estadd scalar cdf1 = e(cdf)':first_weight：将第一阶段回归中的CDF值作为标量cdf1添加到结果中。
这里，first_weight`是第一阶段回归的名称。切记需要是savefprefix()内的名称加上内生解释变量名称。


esttab first_weight m1 using "第一阶段结果.rtf", ///：使用esttab命令输出回归结果到RTF文件。


first_weight m1：指定要输出的模型结果。
using：后跟文件路径，指明结果输出的位置和文件名。

后续参数设置了esttab命令的输出格式：
coeflabels(_cons "常数项")：将常数项的标签更改为"常数项"。
replace：如果输出文件已存在，替换它。
b(3) se(3)：设置系数和标准误的小数位数为3。
compress：减少表格中的空白。
scalar(F)：输出F统计量。
order(trunk weight price mpg length)：指定变量在输出表格中的顺序。

stats(N r2 cdf1 sstat1, fmt(0 3 3 3) labels("观测值" "拟合优度" "CD Wald F" "SW S stat."))：输出额外的统计量，包括观测值数、拟合优度、CDF和S统计量，以及它们的格式，并为额外统计量设置标签。

nobaselevels：不显示基准水平。star(* 0.10 ** 0.05 *** 0.01)：设置显著性水平的星号标记。

*/


*---------------------
*-> 3.3 xtreg 回归分析
*---------------------
	*xtreg, fe是固定效应模型的官方命令，使用这一命令估计出来的系数是最为纯正的固定效应估计量（组内估计量）
*注意事项：1.xtreg对数据格式有严格要求，要求必须是面板数据；
	
*如果要额外控制其他固定效应，必须要在控制变量中加入该效应，比如需要额外控制年份、地区，命令应当誊写为： 
xtreg invest mvalue kstock i.province i.year, fe
*基本语法：
. xtset company year // 必须设定面板数据· xtreg y x control , fe	
· xtreg y x control , fe
	
cd "C:\Users\czxia\Desktop\stata ch3 "
use "Dec 1.dta",clear	

xtset city year
xtreg patent books gdp_per population
	
*---------------------
*-> 3.4 reghdfe 回归分析
*---------------------

Regularization for High Dimensional Fixed Effects
 /*reghdfe该命令吸收了面板线性回归多层次的固定效应，可以进行高维/多维面板固定效应模型估计。
reghdfe是areg(和xtreg,fe, xtivreg,fe)的一般化，用于多水平固定效应(包括异质斜率)、
备选估计量(2sls, gmm2s, liml)和附加鲁棒标准误差。    

 reghdfe命令可以包含多维固定效应模型，只需 absorb (var1,var2,var3,...)，不需要使用i.var的方式引入虚拟变量，相比xtreg命令方便许多，
+并且不会汇报一大长串虚拟变量回归结果。
reghdfe是一个外部命令，所以大家在使用之前需要安装（ssc install reghdfe进行下载）。



reghdfe是非官方命令，在安装过程中需要面临较多的技术难题，
（1）不汇报截距项；
（2）回归过程中会删掉几个样本。要解决这些问题需要较为复杂的安装过程。

基本语法：*/

 reghdfe depvar [indepvars] [if] [in] [weight] , absorb(absvars) [options]

 ssc install reghdfe
 
reghdfe y x c,absorb(个体 时间)(absorb括号中为固定效应)
reghdfe y x c,absorb(个体 时间) vce(robust)(稳健标准误)
reghdfe y x c,absorb(个体时间)vce(cluster 个体)(个体层面聚类稳健标准误)
注:reghdfe命令后 vce(cluster聚类变量)可任意更换，xtreg不可



reghdfe patent books gdp_per population, absorb(city year) 
reghdfe patent books gdp_per population, absorb(city year) vce(robust)

 	
*---------------------
*-> 3.5 ivreghdfe 回归分析
*---------------------
	
 
 ssc install ivreghdfe
 
 ivreghdfe depvar [varlist1] (varlist2=varlist_iv) [if] [in] [weight] , absorb(absvars) [options]
 ivreghdfe Y (X1 = IV1) X2, absorb(Fe1 = id Fe2 = year)
 /*
 ivreghdfe首先基于reghdfe，利用组内去均值法，去除所有变量里面的固定效应。
☟ 然后取均值完成以后，再采用ivreg2进行估计，简单来说就是将去均值的变量采用工具变量法回归。
☟ 最后，因为估计过程去均值，截距项变成0，因而ivreghdfe没有截距项的估计结果
 
 */
 
 
 
 
*---------------------
*-> 4 输出结果
*---------------------
 
 esttab 
 *该命令无法通过运行代码ssc install esttab直接安装，需要先使用如下代码查找该命令：

 
 outreg2
 
 
*---------------------
*-> 4.1  esttab estout
*---------------------


findit esttab //  选第一个即可，点击安装

ssc install estout, replace
**output regression results

*way 1
reg patent books gdp_per gdp_per2 population i.city i.year 
est store patent_1

esttab patent_1,se star keep(*) b(%6.4f)  ar2(4) star(* 0.1 ** 0.05 *** 0.01) replace

esttab patent_1,se star keep(gdp_per books) b(%6.4f)  ar2(4) star(* 0.1 ** 0.05 *** 0.01) replace


reg books gdp_per i.year i.city 
est store books_2

esttab patent_1 books_2,se star keep(gdp_per) b(%6.4f)  ar2(4) star(* 0.1 ** 0.05 *** 0.01) replace



*Practice: 对比展示省会城市和非省会城市的人口对创新能力的影响


reg patent books gdp_per gdp_per2 population i.city i.year if major==1
est store major

reg patent books gdp_per gdp_per2 population i.city i.year if major==0
est store nonmajor

esttab major nonmajor,se star keep(population) b(%6.4f)  ar2(4) star(* 0.1 ** 0.05 *** 0.01) replace


 
*---------------------
*-> 4.2  outreg2
*---------------------

ssc install outreg2

**output regression results
reg patent books gdp_per gdp_per2 population i.city i.year 

outreg2 using 	sample2.doc, replace word label ///
					keep(*)	///
					ctitle(" Y=Patent ") addtext(City FE, Y, Year FE, Y) ///
					nonotes	///
					addnote(*p<.05; **p<.01; ***p<.001.)
*中文label 会乱码
*因此....
	
	
gen patent1=patent //patent的标签不会被复制到新变量中

foreach x of varlist books gdp_per gdp_per2 population city year{
gen `x'1=`x'
}

reg patent1 books1 gdp_per1 gdp_per21 population1 i.city1 i.year1

outreg2 using 	sample2.doc, replace word label ///
					keep(*)	///
					ctitle(" Y=Patent ") addtext(City FE, Y, Year FE, Y) ///
					nonotes	///
					addnote(*p<.05; **p<.01; ***p<.001.)


qui reg patent1 books1 gdp_per1 gdp_per21 population1 i.city1 i.year1

outreg2 using 	sample_quiet.doc, replace word label ///
					keep(*)	///
					ctitle(" Y=Patent ") addtext(City FE, Y, Year FE, Y) ///
					nonotes	///
					addnote(*p<.05; **p<.01; ***p<.001.)

   





